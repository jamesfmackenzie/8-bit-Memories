8-bit-Memories
==============

Inspired by the 8-bit videogames era. A personal blogging theme for Ghost.
